import numpy as np
import tobii_research as tr
import random
import os
import pandas as pd
import csv

from flask import Flask, render_template, request, session, redirect, url_for, jsonify


app = Flask(__name__)

pid = '000'  #Zihan: UPDATE FOR EACH PARTICIPANT
pathname = f'/Users/zihanfang/Desktop/webcam/webcam_participants/{pid}' 
os.makedirs(pathname, exist_ok=True)
os.makedirs(f'{pathname}/tobii', exist_ok=True)
os.makedirs(f'{pathname}/webgazer', exist_ok=True)
os.makedirs(f'{pathname}/responses', exist_ok=True)

# determine task order
stimuli = np.array([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12])
shuffled = random.sample(list(stimuli), 12)

#    ORDER OF STIMULI    #
# note: want 10 & 11 to stay consecutive (they use the same tree)
if shuffled.index(10) < shuffled.index(11):
    temp = shuffled[shuffled.index(10) + 1]
    shuffled[shuffled.index(11)] = temp
    shuffled[shuffled.index(10) + 1] = 11
else:
    temp = shuffled[shuffled.index(11) + 1]
    shuffled[shuffled.index(10)] = temp
    shuffled[shuffled.index(11) + 1] = 10

print(f'Order of stimuli:{shuffled}')


#    FROM ZACH    #
# setting up eye-tracker and making sure we can get data from it
def eye_tracker_setup():
    found_eyetrackers = tr.find_all_eyetrackers()
    if not found_eyetrackers:
        print('cannot find eyetracker')
    else:
        my_eyetracker = found_eyetrackers[0]
    return my_eyetracker


# ZK: function for recording gaze data. you don't need to worry about how this fits into the progression
# from stimulus 1 -> 2 -> 3. Since you subscribe to it in the main function, it should keep going
def tobii_data_callback(gaze_data,index):
    stimulus_number = f'stimulus{shuffled[index]}' # Danielle - trying to create column that provides stimulus number ... not working
    system_timestamp = gaze_data['system_time_stamp']
    device_timestamp = gaze_data['device_time_stamp']
    gaze_validity_left = gaze_data['left_gaze_point_validity']
    gaze_validity_right = gaze_data['right_gaze_point_validity']
    gaze_left_eye = gaze_data['left_gaze_point_on_display_area']
    gaze_right_eye = gaze_data['right_gaze_point_on_display_area']
    valid_left_eye_pd = gaze_data['left_pupil_validity']
    valid_right_eye_pd = gaze_data['right_pupil_validity']
    pd_left = gaze_data['left_pupil_diameter']
    pd_right = gaze_data['right_pupil_diameter']
    irl_left_coord = gaze_data['left_gaze_origin_in_user_coordinate_system']
    irl_right_coord = gaze_data['right_gaze_origin_in_user_coordinate_system']
    irl_left_point_on_screen = gaze_data['left_gaze_point_in_user_coordinate_system']
    irl_right_point_on_screen = gaze_data['right_gaze_point_in_user_coordinate_system']

    tobii_outfile = f'{pathname}/tobii/{pid}_tobii.csv'
    # TODO ZK - I'd recommend saving the data separately for each stimulus.
    # That way, if something goes wrong, you don't lose all the data.
    with open(tobii_outfile, 'a+') as f:  # 'a+' means create new file if it doesn't exist, or add to file if it does
        cw = csv.writer(f)
        cw.writerow([pid, stimulus_number, system_timestamp, device_timestamp, gaze_validity_left,
        gaze_validity_right, gaze_left_eye, gaze_right_eye, valid_left_eye_pd, valid_right_eye_pd, pd_left, pd_right,
        irl_left_coord, irl_right_coord, irl_left_point_on_screen, irl_right_point_on_screen])


df = pd.DataFrame()


@app.route('/',)
def welcome():
    return render_template('welcome.html')


@app.route('/calibration')
def calibration():
    return render_template('calibration.html')


@app.route('/stimulus/<int:index>', methods=['GET', 'POST'])
def stimulus(index):

    if request.method == 'POST':
        choice = request.form.get('choice')  # get user's input selection
        df[f'Stimulus{shuffled[index - 1]}'] = [f'Choice: {choice}']
        df.to_csv(f'{pathname}/responses/{pid}_responses.csv')

    if index >= len(shuffled):
        return render_template('completion.html')

    return render_template(f'stimulus{shuffled[index]}.html', index=index+1)

# ChatGPT: Define the route to handle WebGazer data
@app.route('/record_eye_data', methods=['POST'])
def record_eye_data():
    if request.method == 'POST':
        data = request.json  # ChatGPT: Assuming the eye-tracking data is sent as JSON
        print("Received eye-tracking data:", data)
        # adapted from ZK above
        webgazer_outfile = f'{pathname}/webgazer/{pid}_webgazer.csv'
        # TODO ZK - I'd recommend saving the data separately for each stimulus.
        # That way, if something goes wrong, you don't lose all the data.
        stimulus_number = request
        with open(webgazer_outfile, 'a+') as f:
            cw = csv.writer(f)
            cw.writerow([pid, stimulus_number, data])

        return jsonify({"message": "Eye-tracking data received successfully!"})  # ChatGPT

    return jsonify({"error": "Invalid request"}), 400  # ChatGPT


if __name__ == '__main__':
    global my_eyetracker

    # ZK:
    try:
        my_eyetracker = eye_tracker_setup()
        my_eyetracker.subscribe_to(tr.EYETRACKER_GAZE_DATA, tobii_data_callback, as_dictionary=True)
    except:
        UnboundLocalError("WARNING: Couldn't find eyetracker")
    # ZK - To stop recording, you can put these lines of code in your webpage. Maybe at  last stimulus or goodbye page
    # try:
    #    my_eyetracker.unsubscribe_from(tobii_research.EYETRACKER_GAZE_DATA, tobii_data_callback)
    # except:
    #    UnboundLocalError("WARNING: no eyetracker, but the task is over")
    app.run(port=8484, debug=True, ssl_context="adhoc") # ZK - this is in my server file, you might need it here?
    # danielle: added ssl_context to try for https... still does not, but alert is manually disabled in webgazer.js
